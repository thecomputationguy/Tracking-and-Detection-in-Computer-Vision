## Data Description for Task 2

1. There are 6 classes of objects in total, images from the same class are put in the same directory.
2. Data have been divided into train/test set, use only the train set for your classifier training
